pub mod utils;

pub mod mergesort;

pub mod quicksort;

pub mod heapsort;

pub mod dumbsorts;

pub mod simplesorts;