use super::*;

fn depthfirst<G: Graph>(graph: G, start: Box<G::Node>, goal: Box<G::Node>) -> Path<G> {
    
}
