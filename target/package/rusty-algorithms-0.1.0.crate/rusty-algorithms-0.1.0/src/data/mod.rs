//This module contains algorithms that operate on data

//TODO: runlength, finish huffman, test kmeans, documentation

pub mod kmeans;
pub mod huffman;